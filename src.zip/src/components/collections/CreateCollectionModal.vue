<template>

</template>

<script>
export default {
  name: 'CreateCollectionModal',

  data() {
    return {
      isOpenCreateModal: false
    }
  }
}
</script>