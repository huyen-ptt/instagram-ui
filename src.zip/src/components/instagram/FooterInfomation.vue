<template>
  <div>
    <div class="wrapper-link">
      <a>Meta</a>
      <a>BLog</a>
      <a>About</a>
      <a>Jobs</a>
      <a>Helps</a>
      <a>Apl</a>
      <a>Privacy</a>
      <a>Terms</a>
      <a>Top Accounts</a>
      <a>Locations</a>
      <a>Instagram Lite</a>
      <a>Contact Uploading & Non-Users</a>
      <a>Meta Verified</a>
    </div>
    <div class="footer-end">
      <div class="language">
        <a>English</a>
        <svg aria-label="Down chevron icon" class="x1lliihq x1n2onr6" color="rgb(115, 115, 115)"
             fill="rgb(115, 115, 115)" height="12" role="img" viewBox="0 0 24 24" width="12"><title>Down chevron
          icon</title>
          <path
              d="M21 17.502a.997.997 0 0 1-.707-.293L12 8.913l-8.293 8.296a1 1 0 1 1-1.414-1.414l9-9.004a1.03 1.03 0 0 1 1.414 0l9 9.004A1 1 0 0 1 21 17.502Z"></path>
        </svg>
      </div>
      <a>© 2023 Instagram from Meta</a>
    </div>
  </div>
</template>
<style scoped>
.wrapper-link a{
  margin-right: 10px;
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;
  color: rgb(115, 115, 115);
  cursor: pointer;
}
.wrapper-link{
  text-align: center;
}
.language{
  display: flex;
  justify-content: center;
  align-items: center;
  gap:5px;
}
.footer-end{
  margin-right: 10px;
  text-align: center;
  justify-content: center;
  gap:20px;
  display: flex;
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;
  color: rgb(115, 115, 115);
}

</style>