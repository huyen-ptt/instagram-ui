<template>
  <div class="component">
    <h3>Con</h3>
    <p>Tuoi cua toi: </p>
    <button>Thay doi</button>
  </div>
</template>

<script>
</script>
<style scoped>
  .component{
    background: red;
  }
</style>