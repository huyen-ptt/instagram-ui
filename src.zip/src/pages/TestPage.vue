<template>
  <div class="content">
    <h2>Tiêu đề nội dung</h2>
    <div class="favorite-icon">
      <i class="fas fa-heart"></i>
    </div>
    <p>Nội dung của bài viết...</p>
  </div>
</template>

<!--<script>-->
<!--export default -->

<!--</script>-->
<style>
.content {
  position: relative;
}

.favorite-icon {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  opacity: 0;
  transition: opacity 0.3s ease-in-out;
}

.content:hover .favorite-icon {
  opacity: 1;
}

</style>