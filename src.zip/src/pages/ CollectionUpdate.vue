<template>
  <div class="container">
    <div>Update</div>
  </div>
</template>
<script>

</script>
<style scoped>
.container{
  background: #42b983;
}
</style>