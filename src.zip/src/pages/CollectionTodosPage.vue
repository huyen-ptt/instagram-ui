<template>
  <div class="container">
    <div>Todos</div>
  </div>
</template>
<script>

</script>
<style scoped>
.container{
  background: #b3122a;
}
</style>