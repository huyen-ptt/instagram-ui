<template>
  <div class="container">
    <MenuInstagram/>
    <div class="video">
      <div class="item-video">
        <img class="thanh-video" src="https://kenh14cdn.com/2016/k2-2-1480327709662.jpg">
        <div class="emotional-interaction">
          <div class="like-share">
           <div>
             <div @click="likePostFriend"
                  id="heart">
               <i v-if="!like" class="fa-regular fa-heart"></i>
               <i v-else class="fa-sharp fa-solid fa-heart"></i>
             </div>
             <div class="interactions">21.7K</div>
           </div>
            <div>
              <svg aria-label="Comment" class="x1lliihq x1n2onr6 emotional-status"
                   color="rgb(0, 0, 0)" fill="rgb(0, 0, 0)" height="24"
                   role="img" viewBox="0 0 24 24" width="24"><title>Comment</title>
                <path d="M20.656 17.008a9.993 9.993 0 1 0-3.59 3.615L22 22Z" fill="none" stroke="currentColor"
                      stroke-linejoin="round" stroke-width="2"></path>
              </svg>
              <div class="interactions">6378</div>
            </div>
            <div>
              <svg aria-label="Share Post" class="x1lliihq x1n2onr6 emotional-status"
                   color="rgb(0, 0, 0)"
                   fill="rgb(0, 0, 0)"
                   height="24" role="img" viewBox="0 0 24 24" width="24"><title>Share Post</title>
                <line fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="2" x1="22" x2="9.218"
                      y1="3" y2="10.083"></line>
                <polygon fill="none" points="11.698 20.334 22 3.001 2 3.001 9.218 10.084 11.698 20.334"
                         stroke="currentColor" stroke-linejoin="round" stroke-width="2"></polygon>
              </svg>
            </div>
            <div>
              <svg aria-label="Save" class="x1lliihq x1n2onr6 save" color="rgb(0, 0, 0)" fill="rgb(0, 0, 0)"
                   height="24"
                   role="img" viewBox="0 0 24 24" width="24"><title>Save</title>
                <polygon fill="none" points="20 21 12 13.44 4 21 4 3 20 3 20 21" stroke="currentColor"
                         stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></polygon>
              </svg>
            </div>
            <div class="x78zum5 x6s0dn4 xl56j7k xdt5ytf">
              <svg aria-label="More" class="x1lliihq x1n2onr6" color="rgb(38, 38, 38)" fill="rgb(38, 38, 38)"
                   height="24" role="img" viewBox="0 0 24 24" width="24"><title>More</title>
                <circle cx="12" cy="12" r="1.5"></circle>
                <circle cx="6" cy="12" r="1.5"></circle>
                <circle cx="18" cy="12" r="1.5"></circle>
              </svg>
            </div>
            <div>
              <img class="audio" src="https://img5.thuthuatphanmem.vn/uploads/2022/01/07/glitter-mask-hnheldinw_025549768.png">
            </div>
          </div>
        </div>
      </div>
      <div class="item-video">
        <img class="thanh-video" src="https://vtv1.mediacdn.vn/thumb_w/640/2022/12/23/photo-2-1671785628973971302042.jpg">
        <div class="emotional-interaction">
          <div class="like-share">
            <div @click="likePostFriend"
                 id="heart">
              <i v-if="!like" class="fa-regular fa-heart"></i>
              <i v-else class="fa-sharp fa-solid fa-heart"></i>
              <div>21.7K</div>
            </div>
            <svg aria-label="Comment" class="x1lliihq x1n2onr6 emotional-status"
                 color="rgb(0, 0, 0)" fill="rgb(0, 0, 0)" height="24"
                 role="img" viewBox="0 0 24 24" width="24"><title>Comment</title>
              <path d="M20.656 17.008a9.993 9.993 0 1 0-3.59 3.615L22 22Z" fill="none" stroke="currentColor"
                    stroke-linejoin="round" stroke-width="2"></path>
            </svg>
            <div>21.7K</div>
            <div>
              <svg aria-label="Share Post" class="x1lliihq x1n2onr6 emotional-status"
                   color="rgb(0, 0, 0)"
                   fill="rgb(0, 0, 0)"
                   height="24" role="img" viewBox="0 0 24 24" width="24"><title>Share Post</title>
                <line fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="2" x1="22" x2="9.218"
                      y1="3" y2="10.083"></line>
                <polygon fill="none" points="11.698 20.334 22 3.001 2 3.001 9.218 10.084 11.698 20.334"
                         stroke="currentColor" stroke-linejoin="round" stroke-width="2"></polygon>
              </svg>
            </div>
            <div>
              <svg aria-label="Save" class="x1lliihq x1n2onr6 save" color="rgb(0, 0, 0)" fill="rgb(0, 0, 0)"
                   height="24"
                   role="img" viewBox="0 0 24 24" width="24"><title>Save</title>
                <polygon fill="none" points="20 21 12 13.44 4 21 4 3 20 3 20 21" stroke="currentColor"
                         stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></polygon>
              </svg>
            </div>
            <div class="x78zum5 x6s0dn4 xl56j7k xdt5ytf">
              <svg aria-label="More" class="x1lliihq x1n2onr6" color="rgb(38, 38, 38)" fill="rgb(38, 38, 38)"
                   height="24" role="img" viewBox="0 0 24 24" width="24"><title>More</title>
                <circle cx="12" cy="12" r="1.5"></circle>
                <circle cx="6" cy="12" r="1.5"></circle>
                <circle cx="18" cy="12" r="1.5"></circle>
              </svg>
            </div>
            <div>
              <img class="audio" src="https://img5.thuthuatphanmem.vn/uploads/2022/01/07/glitter-mask-hnheldinw_025549768.png">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import MenuInstagram from "@/components/instagram/MenuInstagram.vue";

export default {
  components: {
    MenuInstagram
  },
  data(){
    return{
      like: false,
    }
  },
  methods:{
    likePostFriend() {
      if (!this.like) {
        this.like = true
      } else {
        this.like = false
      }
    }

  }


}
</script>
<style scoped>
.container {
  background: #FFFFFF;
  display: flex;
  width: 100%;
  height: 100vh;
  overflow: auto;
}
.like-share svg{
  font-size: 24px;
}
.interactions{
  font-size: 13px;
  font-weight: 400;
}
.fa-heart{
  font-size: 24px;
}
.audio{
  width: 20px;
  border-radius: 2px;
}
.emotional-interaction{
  position: absolute;
  bottom: 32px;
  right: -65px;
}
.like-share{
  display: flex;
  justify-content: center;
  flex-direction: column;
  gap:15px;
}
.video {
  display: grid;
  grid-template-columns: 1fr;
 overflow: auto;
  flex: 1;
  min-width: 1px;
  width: 100%;
  padding: 35px 0;

}

.item-video {
  position: relative;
  margin: 0 auto;
  display: flex;
  gap: 20px;
}

.item-video .thanh-video {
  width: 400px;
  height: 700px;
  padding-bottom: 30px;
  border-radius: 8px;
}

</style>