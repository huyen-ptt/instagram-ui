<template>
  <div class="container">
    <div> Create</div>
  </div>
</template>
<script>

</script>
<style scoped>
.container{
  background: #ab1fbb;
}
</style>